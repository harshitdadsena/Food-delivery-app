import { useEffect, useRef, useState } from 'react';
import { 
  Search, 
  MapPin, 
  Clock, 
  Users, 
  ChevronRight, 
  Star, 
  Heart, 
  Utensils,
  ShoppingCart,
  Map,
  Smile,
  Apple,
  Play,
  Facebook,
  Twitter,
  Instagram,
  Linkedin,
  Menu,
  X,
  ArrowRight,
  CheckCircle2,
  Thermometer
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

// Navigation Component
function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled 
          ? 'bg-white/90 backdrop-blur-lg shadow-lg py-3' 
          : 'bg-transparent py-5'
      }`}
    >
      <div className="section-container">
        <div className="section-inner flex items-center justify-between">
          {/* Logo */}
          <div 
            className="flex items-center gap-2 cursor-pointer"
            onClick={() => scrollToSection('hero')}
          >
            <div className="w-10 h-10 bg-[#e94339] rounded-full flex items-center justify-center">
              <Utensils className="w-5 h-5 text-white" />
            </div>
            <span className={`text-xl font-bold transition-colors ${isScrolled ? 'text-gray-900' : 'text-gray-900'}`}>
              Food<span className="text-[#e94339]">Dash</span>
            </span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {[
              { label: 'Home', id: 'hero' },
              { label: 'About', id: 'about' },
              { label: 'How It Works', id: 'steps' },
              { label: 'Restaurants', id: 'features' },
              { label: 'Reviews', id: 'testimonials' },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`text-sm font-medium transition-colors hover:text-[#e94339] ${
                  isScrolled ? 'text-gray-700' : 'text-gray-700'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center gap-4">
            <Button 
              variant="ghost" 
              className="text-sm font-medium hover:text-[#e94339]"
              onClick={() => scrollToSection('cta')}
            >
              Download App
            </Button>
            <Button 
              className="btn-primary text-sm"
              onClick={() => scrollToSection('hero')}
            >
              Order Now
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? (
              <X className="w-6 h-6 text-gray-900" />
            ) : (
              <Menu className="w-6 h-6 text-gray-900" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-white shadow-lg py-4 px-4">
          <div className="flex flex-col gap-4">
            {[
              { label: 'Home', id: 'hero' },
              { label: 'About', id: 'about' },
              { label: 'How It Works', id: 'steps' },
              { label: 'Restaurants', id: 'features' },
              { label: 'Reviews', id: 'testimonials' },
              { label: 'Download App', id: 'cta' },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className="text-left text-gray-700 font-medium py-2 hover:text-[#e94339] transition-colors"
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}

// Hero Section
function HeroSection() {
  const [isVisible, setIsVisible] = useState(false);
  const [searchFocused, setSearchFocused] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <section 
      id="hero" 
      ref={sectionRef}
      className="relative min-h-screen w-full overflow-hidden pt-20"
    >
      {/* Background Gradient */}
      <div 
        className={`absolute inset-0 transition-all duration-1200 ${
          isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-110'
        }`}
        style={{
          background: `
            radial-gradient(ellipse at 20% 30%, rgba(255, 204, 0, 0.25) 0%, transparent 50%),
            radial-gradient(ellipse at 80% 70%, rgba(233, 67, 57, 0.15) 0%, transparent 50%),
            radial-gradient(ellipse at 50% 50%, rgba(255, 224, 102, 0.15) 0%, transparent 70%),
            linear-gradient(135deg, #fff9e6 0%, #ffffff 50%, #fff0f0 100%)
          `,
          backgroundSize: '200% 200%',
        }}
      />

      {/* Decorative Circles */}
      <div 
        className={`absolute top-20 right-20 w-64 h-64 rounded-full border-2 border-dashed border-[#e94339]/20 animate-slow-rotate transition-all duration-1000 delay-800 ${
          isVisible ? 'opacity-100' : 'opacity-0'
        }`}
      />
      <div 
        className={`absolute bottom-40 left-10 w-32 h-32 rounded-full border-2 border-dashed border-[#ffcc00]/30 animate-slow-rotate transition-all duration-1000 delay-1000 ${
          isVisible ? 'opacity-100' : 'opacity-0'
        }`}
        style={{ animationDirection: 'reverse' }}
      />

      <div className="section-container relative z-10">
        <div className="section-inner min-h-[calc(100vh-80px)] flex items-center">
          <div className="grid lg:grid-cols-2 gap-12 items-center w-full py-12">
            {/* Left Content */}
            <div className="space-y-8">
              {/* Headline */}
              <div className="space-y-2">
                {['Crave It?', "We'll Deliver", 'In Minutes!'].map((line, i) => (
                  <h1 
                    key={i}
                    className={`text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 transition-all duration-600 ${
                      isVisible 
                        ? 'opacity-100 translate-y-0' 
                        : 'opacity-0 translate-y-8'
                    }`}
                    style={{ 
                      transitionDelay: `${400 + i * 120}ms`,
                      fontFamily: "'Paytone One', sans-serif"
                    }}
                  >
                    {line}
                  </h1>
                ))}
              </div>

              {/* Subtext */}
              <p 
                className={`text-lg text-gray-600 max-w-md transition-all duration-500 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'
                }`}
                style={{ transitionDelay: '800ms' }}
              >
                Discover the best food from over 1,000 restaurants and fast delivery to your doorstep
              </p>

              {/* Search Bar */}
              <div 
                className={`flex flex-col sm:flex-row gap-3 max-w-lg transition-all duration-600 ${
                  isVisible ? 'opacity-100 scale-100 translate-y-0' : 'opacity-0 scale-95 translate-y-8'
                }`}
                style={{ transitionDelay: '900ms' }}
              >
                <div className={`flex-1 relative transition-all duration-300 ${searchFocused ? 'scale-[1.02]' : ''}`}>
                  <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input 
                    type="text"
                    placeholder="Enter your delivery address"
                    className={`w-full pl-12 pr-4 py-6 rounded-full border-2 transition-all duration-300 ${
                      searchFocused 
                        ? 'border-[#e94339] ring-4 ring-[#e94339]/20' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onFocus={() => setSearchFocused(true)}
                    onBlur={() => setSearchFocused(false)}
                  />
                </div>
                <Button className="btn-primary py-6 px-8 flex items-center gap-2">
                  <Search className="w-5 h-5" />
                  Find Food
                </Button>
              </div>

              {/* Stats */}
              <div 
                className={`flex flex-wrap gap-6 sm:gap-10 transition-all duration-500 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'
                }`}
                style={{ transitionDelay: '1000ms' }}
              >
                {[
                  { icon: Utensils, value: '1000+', label: 'Restaurants' },
                  { icon: Clock, value: '30min', label: 'Avg Delivery' },
                  { icon: Users, value: '50K+', label: 'Happy Customers' },
                ].map((stat, i) => (
                  <div 
                    key={i} 
                    className="flex items-center gap-3 animate-count-up"
                    style={{ animationDelay: `${1000 + i * 100}ms` }}
                  >
                    <div className="w-12 h-12 bg-[#e94339]/10 rounded-full flex items-center justify-center">
                      <stat.icon className="w-5 h-5 text-[#e94339]" />
                    </div>
                    <div>
                      <p className="text-xl font-bold text-gray-900">{stat.value}</p>
                      <p className="text-sm text-gray-500">{stat.label}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right Content - Phone Mockup */}
            <div 
              className={`relative flex justify-center lg:justify-end transition-all duration-1000 ${
                isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-20'
              }`}
              style={{ transitionDelay: '600ms' }}
            >
              <div className="perspective-container">
                <div 
                  className="relative animate-gentle-float"
                  style={{ transformStyle: 'preserve-3d' }}
                >
                  {/* Phone Shadow */}
                  <div 
                    className="absolute -bottom-10 left-1/2 -translate-x-1/2 w-48 h-12 bg-black/20 rounded-full blur-2xl"
                    style={{ transform: 'translateZ(-30px)' }}
                  />
                  
                  {/* Phone Mockup */}
                  <img 
                    src="/phone-mockup.png" 
                    alt="FoodDash App"
                    className="w-64 sm:w-80 lg:w-96 h-auto drop-shadow-2xl transition-transform duration-500 hover:rotate-y-[-5deg] hover:rotate-x-[5deg]"
                    style={{ transformStyle: 'preserve-3d' }}
                  />

                  {/* Floating Badge */}
                  <div 
                    className={`absolute -left-4 top-1/4 bg-white rounded-xl shadow-xl p-3 flex items-center gap-3 transition-all duration-600 ${
                      isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'
                    }`}
                    style={{ 
                      transitionDelay: '1200ms',
                      animation: 'gentle-float 5s ease-in-out infinite 0.5s'
                    }}
                  >
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                      <CheckCircle2 className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-900">Order Placed!</p>
                      <p className="text-xs text-gray-500">On its way</p>
                    </div>
                  </div>

                  {/* Another Floating Badge */}
                  <div 
                    className={`absolute -right-4 bottom-1/3 bg-white rounded-xl shadow-xl p-3 flex items-center gap-3 transition-all duration-600 ${
                      isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'
                    }`}
                    style={{ 
                      transitionDelay: '1400ms',
                      animation: 'gentle-float 6s ease-in-out infinite 1s'
                    }}
                  >
                    <div className="w-10 h-10 bg-[#ffcc00]/20 rounded-full flex items-center justify-center">
                      <Star className="w-5 h-5 text-[#ffcc00] fill-[#ffcc00]" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-900">4.9 Rating</p>
                      <p className="text-xs text-gray-500">Top rated</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// About/Banner Section
function AboutSection() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const features = [
    { icon: Map, text: 'Live order tracking' },
    { icon: Clock, text: 'Real-time ETA updates' },
    { icon: Thermometer, text: 'Temperature-controlled delivery' },
  ];

  return (
    <section 
      id="about" 
      ref={sectionRef}
      className="relative py-20 lg:py-32 w-full overflow-hidden"
    >
      <div className="section-container">
        <div className="section-inner">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            {/* Image */}
            <div 
              className={`relative transition-all duration-800 ${
                isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-20'
              }`}
            >
              <div className="relative">
                <img 
                  src="/delivery-person.png" 
                  alt="Delivery Partner"
                  className="w-full max-w-lg mx-auto lg:mx-0 h-auto transition-transform duration-400 hover:scale-[1.02]"
                />
                
                {/* Floating Stat Card */}
                <div 
                  className={`absolute right-0 lg:-right-8 top-1/2 -translate-y-1/2 bg-white rounded-2xl shadow-2xl p-6 transition-all duration-600 ${
                    isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-12'
                  }`}
                  style={{ 
                    transitionDelay: '800ms',
                    animation: 'card-float 4s ease-in-out infinite'
                  }}
                >
                  <p className="text-4xl font-bold text-[#e94339]">15min</p>
                  <p className="text-sm font-semibold text-gray-900">Fastest Delivery</p>
                  <p className="text-xs text-gray-500">In your area</p>
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="space-y-6">
              <h2 
                className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 transition-all duration-500 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
                }`}
                style={{ transitionDelay: '300ms', fontFamily: "'Paytone One', sans-serif" }}
              >
                Fastest Delivery Service In Your City
              </h2>

              <p 
                className={`text-lg text-gray-600 transition-all duration-500 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: '400ms' }}
              >
                We pride ourselves on speed without compromise. Our network of dedicated delivery partners ensures your food arrives fresh, hot, and exactly when you expect it.
              </p>

              {/* Features */}
              <div className="space-y-4 pt-4">
                {features.map((feature, i) => (
                  <div 
                    key={i}
                    className={`flex items-center gap-4 group cursor-pointer transition-all duration-400 ${
                      isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-5'
                    }`}
                    style={{ transitionDelay: `${500 + i * 100}ms` }}
                  >
                    <div className="w-12 h-12 bg-[#e94339]/10 rounded-full flex items-center justify-center transition-all duration-300 group-hover:bg-[#e94339] group-hover:scale-110 group-hover:rotate-[10deg]">
                      <feature.icon className="w-5 h-5 text-[#e94339] transition-colors group-hover:text-white" />
                    </div>
                    <span className="text-gray-700 font-medium transition-colors group-hover:text-[#e94339]">
                      {feature.text}
                    </span>
                  </div>
                ))}
              </div>

              {/* CTA */}
              <div 
                className={`pt-4 transition-all duration-400 ${
                  isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-90'
                }`}
                style={{ transitionDelay: '800ms' }}
              >
                <Button className="btn-secondary group">
                  Learn More About Us
                  <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// How It Works Section
function StepsSection() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const steps = [
    {
      number: '01',
      icon: Search,
      title: 'Choose Your Food',
      description: 'Browse menus from thousands of local restaurants and find your perfect meal.',
    },
    {
      number: '02',
      icon: ShoppingCart,
      title: 'Place Your Order',
      description: 'Customize your meal and checkout securely in seconds with our easy-to-use app.',
    },
    {
      number: '03',
      icon: Map,
      title: 'Track Delivery',
      description: 'Watch your order journey from kitchen to doorstep with live tracking.',
    },
    {
      number: '04',
      icon: Smile,
      title: 'Enjoy Your Meal',
      description: 'Fresh, hot food delivered right when you want it. Enjoy every bite!',
    },
  ];

  return (
    <section 
      id="steps" 
      ref={sectionRef}
      className="relative py-20 lg:py-32 w-full overflow-hidden bg-[#f9f9f9]"
    >
      <div className="section-container">
        <div className="section-inner">
          {/* Header */}
          <div className="text-center mb-16">
            <h2 
              className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4 transition-all duration-500 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ fontFamily: "'Paytone One', sans-serif" }}
            >
              How It Works
            </h2>
            <p 
              className={`text-lg text-gray-600 transition-all duration-500 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
              style={{ transitionDelay: '100ms' }}
            >
              Get your favorite food in 4 simple steps
            </p>
          </div>

          {/* Steps Grid */}
          <div className="relative">
            {/* Connection Line (Desktop) */}
            <div className="hidden lg:block absolute top-24 left-0 right-0 h-1">
              <div 
                className={`h-full bg-gradient-to-r from-[#e94339] via-[#ffcc00] to-[#e94339] rounded-full transition-all duration-1500 ${
                  isVisible ? 'opacity-100 scale-x-100' : 'opacity-0 scale-x-0'
                }`}
                style={{ 
                  transitionDelay: '300ms',
                  transformOrigin: 'left'
                }}
              />
            </div>

            {/* Steps */}
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {steps.map((step, i) => (
                <div 
                  key={i}
                  className={`relative bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-400 group card-3d ${
                    isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-90'
                  }`}
                  style={{ transitionDelay: `${400 + i * 150}ms` }}
                >
                  {/* Step Number */}
                  <div 
                    className={`absolute -top-4 left-8 w-12 h-12 bg-[#e94339] text-white rounded-full flex items-center justify-center font-bold text-lg shadow-lg transition-all duration-300 group-hover:scale-110 ${
                      isVisible ? 'animate-step-pulse' : ''
                    }`}
                    style={{ animationDelay: `${i * 0.5}s` }}
                  >
                    {i + 1}
                  </div>

                  {/* Icon */}
                  <div className="mt-6 mb-6">
                    <div className="w-16 h-16 bg-[#e94339]/10 rounded-2xl flex items-center justify-center transition-all duration-300 group-hover:bg-[#e94339] group-hover:scale-110 animate-icon-float">
                      <step.icon className="w-8 h-8 text-[#e94339] transition-colors group-hover:text-white" />
                    </div>
                  </div>

                  {/* Content */}
                  <h3 className="text-xl font-bold text-gray-900 mb-3">
                    {step.title}
                  </h3>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {step.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// Featured Restaurants Section
function FeaturesSection() {
  const [isVisible, setIsVisible] = useState(false);
  const [favorites, setFavorites] = useState<number[]>([]);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const toggleFavorite = (id: number) => {
    setFavorites(prev => 
      prev.includes(id) 
        ? prev.filter(f => f !== id)
        : [...prev, id]
    );
  };

  const restaurants = [
    {
      id: 1,
      name: "Mario's Pizza",
      category: 'Italian • Pizza',
      rating: 4.8,
      reviews: '2.1k',
      delivery: '25-35 min',
      fee: 'Free delivery',
      image: '/pizza.jpg',
    },
    {
      id: 2,
      name: 'Sakura Sushi',
      category: 'Japanese • Sushi',
      rating: 4.9,
      reviews: '1.8k',
      delivery: '30-45 min',
      fee: '$2.99 delivery',
      image: '/sushi.jpg',
    },
    {
      id: 3,
      name: 'Burger King',
      category: 'American • Burgers',
      rating: 4.6,
      reviews: '3.2k',
      delivery: '20-30 min',
      fee: 'Free delivery',
      image: '/burger.jpg',
    },
  ];

  return (
    <section 
      id="features" 
      ref={sectionRef}
      className="relative py-20 lg:py-32 w-full overflow-hidden"
    >
      <div className="section-container">
        <div className="section-inner">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-6 mb-12">
            <div>
              <h2 
                className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4 transition-all duration-500 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ fontFamily: "'Paytone One', sans-serif" }}
              >
                Featured Restaurants
              </h2>
              <p 
                className={`text-lg text-gray-600 transition-all duration-500 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
                }`}
                style={{ transitionDelay: '100ms' }}
              >
                Handpicked favorites from your neighborhood
              </p>
            </div>
            <Button 
              variant="outline" 
              className={`group border-[#e94339] text-[#e94339] hover:bg-[#e94339] hover:text-white transition-all duration-400 ${
                isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-90'
              }`}
              style={{ transitionDelay: '200ms' }}
            >
              View All Restaurants
              <ChevronRight className="w-4 h-4 ml-1 transition-transform group-hover:translate-x-1" />
            </Button>
          </div>

          {/* Restaurant Cards */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {restaurants.map((restaurant, i) => (
              <div 
                key={restaurant.id}
                className={`group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-400 card-3d ${
                  isVisible ? 'opacity-100' : 'opacity-0'
                }`}
                style={{ 
                  transitionDelay: `${200 + i * 150}ms`,
                  animation: isVisible ? `flip-in 0.6s var(--ease-out-expo) ${200 + i * 150}ms forwards` : 'none',
                  opacity: isVisible ? 1 : 0
                }}
              >
                {/* Image */}
                <div className="relative h-56 overflow-hidden">
                  <img 
                    src={restaurant.image}
                    alt={restaurant.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  
                  {/* Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-400" />
                  
                  {/* Favorite Button */}
                  <button 
                    onClick={() => toggleFavorite(restaurant.id)}
                    className="absolute top-4 right-4 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-lg transition-all duration-300 hover:scale-110"
                  >
                    <Heart 
                      className={`w-5 h-5 transition-all duration-300 ${
                        favorites.includes(restaurant.id) 
                          ? 'text-[#e94339] fill-[#e94339] animate-heart-pulse' 
                          : 'text-gray-600'
                      }`} 
                    />
                  </button>

                  {/* Delivery Badge */}
                  <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-[#e94339]" />
                    <span className="text-xs font-medium text-gray-900">{restaurant.delivery}</span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="text-lg font-bold text-gray-900 group-hover:text-[#e94339] transition-colors">
                        {restaurant.name}
                      </h3>
                      <p className="text-sm text-gray-500">{restaurant.category}</p>
                    </div>
                    <div className="flex items-center gap-1 bg-green-50 px-2 py-1 rounded-lg">
                      <Star className="w-4 h-4 text-green-600 fill-green-600" />
                      <span className="text-sm font-semibold text-green-600">{restaurant.rating}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100">
                    <span className="text-sm text-gray-500">({restaurant.reviews} reviews)</span>
                    <span className="text-sm font-medium text-[#e94339]">{restaurant.fee}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// CTA / Download App Section
function CTASection() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section 
      id="cta" 
      ref={sectionRef}
      className="relative py-20 lg:py-32 w-full overflow-hidden"
    >
      {/* Background Pattern */}
      <div 
        className="absolute inset-0 opacity-5 animate-pattern-drift"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23e94339' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}
      />

      {/* Gradient Overlay */}
      <div 
        className="absolute inset-0"
        style={{
          background: 'linear-gradient(135deg, rgba(255,249,230,0.9) 0%, rgba(255,255,255,0.95) 50%, rgba(255,240,240,0.9) 100%)',
        }}
      />

      <div className="section-container relative z-10">
        <div className="section-inner">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            {/* Content */}
            <div className="space-y-8">
              <h2 
                className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 transition-all duration-600 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
                }`}
                style={{ fontFamily: "'Paytone One', sans-serif" }}
              >
                Get The App From Google Play or App Store
              </h2>

              <p 
                className={`text-lg text-gray-600 transition-all duration-500 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: '200ms' }}
              >
                Order anytime, anywhere. Track your delivery in real-time, save your favorites, and unlock exclusive app-only deals.
              </p>

              {/* App Store Buttons */}
              <div 
                className={`flex flex-wrap gap-4 transition-all duration-500 ${
                  isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'
                }`}
                style={{ transitionDelay: '400ms' }}
              >
                <button className="flex items-center gap-3 bg-black text-white px-6 py-3 rounded-xl hover:bg-gray-800 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl group">
                  <Apple className="w-8 h-8" />
                  <div className="text-left">
                    <p className="text-xs text-gray-400">Download on the</p>
                    <p className="text-sm font-semibold">App Store</p>
                  </div>
                </button>
                <button className="flex items-center gap-3 bg-black text-white px-6 py-3 rounded-xl hover:bg-gray-800 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl group">
                  <Play className="w-8 h-8 fill-current" />
                  <div className="text-left">
                    <p className="text-xs text-gray-400">Get it on</p>
                    <p className="text-sm font-semibold">Google Play</p>
                  </div>
                </button>
              </div>

              {/* Social Proof */}
              <div 
                className={`flex flex-wrap gap-6 transition-all duration-500 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
                }`}
                style={{ transitionDelay: '600ms' }}
              >
                {[
                  { icon: Star, text: '4.9 Rating' },
                  { icon: Users, text: '100K+ Downloads' },
                  { icon: Heart, text: 'Loved by foodies' },
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <item.icon className={`w-5 h-5 ${i === 0 ? 'text-[#ffcc00] fill-[#ffcc00]' : 'text-[#e94339]'}`} />
                    <span className="text-sm font-medium text-gray-700">{item.text}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Phone Mockup */}
            <div 
              className={`relative flex justify-center transition-all duration-800 ${
                isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-20'
              }`}
              style={{ transitionDelay: '300ms' }}
            >
              <div className="perspective-container">
                <div 
                  className="relative animate-gentle-float"
                  style={{ transformStyle: 'preserve-3d' }}
                >
                  {/* Phone Shadow */}
                  <div 
                    className="absolute -bottom-8 left-1/2 -translate-x-1/2 w-40 h-8 bg-black/20 rounded-full blur-xl"
                  />
                  
                  {/* Phone */}
                  <img 
                    src="/phone-mockup.png"
                    alt="FoodDash App"
                    className="w-56 sm:w-72 h-auto drop-shadow-2xl transition-transform duration-500 hover:rotate-y-[-5deg]"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// Testimonials Section
function TestimonialsSection() {
  const [isVisible, setIsVisible] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Auto-rotate testimonials
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex(prev => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const testimonials = [
    {
      name: 'Sarah Johnson',
      role: 'Food Enthusiast',
      quote: "The fastest delivery I've ever experienced! My pizza was still piping hot when it arrived. Absolutely love the real-time tracking feature.",
      rating: 5,
      avatar: '/avatar-sarah.jpg',
    },
    {
      name: 'Michael Chen',
      role: 'Busy Professional',
      quote: "As someone who works late, this app is a lifesaver. Great restaurant selection and the app is so easy to use!",
      rating: 5,
      avatar: '/avatar-michael.jpg',
    },
    {
      name: 'Emily Rodriguez',
      role: 'Mom of Three',
      quote: "Feeding a family is so much easier now. The kids love choosing their favorites, and I love the special discounts!",
      rating: 5,
      avatar: '/avatar-emily.jpg',
    },
  ];

  const goToPrev = () => {
    setActiveIndex(prev => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const goToNext = () => {
    setActiveIndex(prev => (prev + 1) % testimonials.length);
  };

  return (
    <section 
      id="testimonials" 
      ref={sectionRef}
      className="relative py-20 lg:py-32 w-full overflow-hidden bg-[#f9f9f9]"
    >
      <div className="section-container">
        <div className="section-inner">
          {/* Header */}
          <div className="text-center mb-16">
            <h2 
              className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4 transition-all duration-500 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ fontFamily: "'Paytone One', sans-serif" }}
            >
              What Our Customers Say
            </h2>
            <p 
              className={`text-lg text-gray-600 transition-all duration-500 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
              style={{ transitionDelay: '100ms' }}
            >
              Real reviews from real food lovers
            </p>
          </div>

          {/* Testimonials Carousel */}
          <div 
            className={`relative max-w-4xl mx-auto transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
            }`}
            style={{ transitionDelay: '200ms' }}
          >
            {/* Quote Mark */}
            <div className="absolute -top-8 left-1/2 -translate-x-1/2 text-8xl text-[#e94339]/10 font-serif animate-quote-float">
              "
            </div>

            {/* Cards Container */}
            <div className="relative overflow-hidden">
              <div 
                className="flex transition-transform duration-500"
                style={{ transform: `translateX(-${activeIndex * 100}%)` }}
              >
                {testimonials.map((testimonial, i) => (
                  <div 
                    key={i}
                    className="w-full flex-shrink-0 px-4"
                  >
                    <div className="bg-white rounded-3xl shadow-xl p-8 sm:p-12 text-center">
                      {/* Avatar */}
                      <div className="relative inline-block mb-6">
                        <img 
                          src={testimonial.avatar}
                          alt={testimonial.name}
                          className="w-20 h-20 rounded-full object-cover border-4 border-white shadow-lg animate-avatar-pulse"
                        />
                      </div>

                      {/* Stars */}
                      <div className="flex justify-center gap-1 mb-6">
                        {[...Array(testimonial.rating)].map((_, j) => (
                          <Star 
                            key={j} 
                            className="w-5 h-5 text-[#ffcc00] fill-[#ffcc00]"
                          />
                        ))}
                      </div>

                      {/* Quote */}
                      <p className="text-lg sm:text-xl text-gray-700 mb-8 leading-relaxed">
                        "{testimonial.quote}"
                      </p>

                      {/* Author */}
                      <div>
                        <p className="font-bold text-gray-900">{testimonial.name}</p>
                        <p className="text-sm text-gray-500">{testimonial.role}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Navigation */}
            <div className="flex items-center justify-center gap-4 mt-8">
              <button 
                onClick={goToPrev}
                className="w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center text-gray-600 hover:bg-[#e94339] hover:text-white transition-all duration-300 hover:scale-110"
              >
                <ChevronRight className="w-5 h-5 rotate-180" />
              </button>

              {/* Dots */}
              <div className="flex gap-2">
                {testimonials.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveIndex(i)}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      i === activeIndex 
                        ? 'bg-[#e94339] w-8' 
                        : 'bg-gray-300 hover:bg-gray-400'
                    }`}
                  />
                ))}
              </div>

              <button 
                onClick={goToNext}
                className="w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center text-gray-600 hover:bg-[#e94339] hover:text-white transition-all duration-300 hover:scale-110"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// Footer Section
function Footer() {
  const [isVisible, setIsVisible] = useState(false);
  const [email, setEmail] = useState('');
  const footerRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (footerRef.current) {
      observer.observe(footerRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Thank you for subscribing with: ${email}`);
    setEmail('');
  };

  const quickLinks = [
    { label: 'About Us', href: '#about' },
    { label: 'Restaurants', href: '#features' },
    { label: 'Cuisines', href: '#' },
    { label: 'Become a Partner', href: '#' },
  ];

  const supportLinks = [
    { label: 'Help Center', href: '#' },
    { label: 'Contact Us', href: '#' },
    { label: 'FAQs', href: '#' },
    { label: 'Terms of Service', href: '#' },
  ];

  const socialLinks = [
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
  ];

  return (
    <footer 
      ref={footerRef}
      className={`relative bg-[#1a1a1a] text-white py-16 w-full overflow-hidden transition-all duration-800 ${
        isVisible ? 'opacity-100' : 'opacity-0'
      }`}
      style={{
        clipPath: isVisible ? 'inset(0 0 0 0)' : 'inset(100% 0 0 0)',
      }}
    >
      <div className="section-container">
        <div className="section-inner">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
            {/* Brand */}
            <div 
              className={`space-y-4 transition-all duration-500 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'
              }`}
              style={{ transitionDelay: '200ms' }}
            >
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 bg-[#e94339] rounded-full flex items-center justify-center animate-logo-glow">
                  <Utensils className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold">
                  Food<span className="text-[#e94339]">Dash</span>
                </span>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed">
                Delivering happiness, one meal at a time. Your favorite food, delivered fast and fresh.
              </p>
            </div>

            {/* Quick Links */}
            <div 
              className={`transition-all duration-500 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'
              }`}
              style={{ transitionDelay: '300ms' }}
            >
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-3">
                {quickLinks.map((link, i) => (
                  <li key={i}>
                    <a 
                      href={link.href}
                      className="text-gray-400 hover:text-[#e94339] transition-all duration-200 hover:translate-x-1 inline-block text-sm"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Support */}
            <div 
              className={`transition-all duration-500 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'
              }`}
              style={{ transitionDelay: '400ms' }}
            >
              <h4 className="text-lg font-semibold mb-4">Support</h4>
              <ul className="space-y-3">
                {supportLinks.map((link, i) => (
                  <li key={i}>
                    <a 
                      href={link.href}
                      className="text-gray-400 hover:text-[#e94339] transition-all duration-200 hover:translate-x-1 inline-block text-sm"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Newsletter */}
            <div 
              className={`transition-all duration-500 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'
              }`}
              style={{ transitionDelay: '500ms' }}
            >
              <h4 className="text-lg font-semibold mb-4">Stay Updated</h4>
              <p className="text-gray-400 text-sm mb-4">
                Get exclusive deals and updates delivered to your inbox.
              </p>
              <form onSubmit={handleSubscribe} className="flex gap-2">
                <Input 
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-white/10 border-white/20 text-white placeholder:text-gray-500 flex-1"
                  required
                />
                <Button 
                  type="submit"
                  className="bg-[#e94339] hover:bg-[#ffcc00] hover:text-black transition-all duration-300"
                >
                  Subscribe
                </Button>
              </form>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
            {/* Social Links */}
            <div className="flex items-center gap-4">
              {socialLinks.map((social, i) => (
                <a
                  key={i}
                  href={social.href}
                  aria-label={social.label}
                  className={`w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-gray-400 hover:bg-[#e94339] hover:text-white transition-all duration-300 hover:-translate-y-1 hover:scale-110 animate-social-float`}
                  style={{ animationDelay: `${i * 0.2}s` }}
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>

            {/* Copyright */}
            <p className="text-gray-500 text-sm">
              © 2024 FoodDash. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}

// Main App Component
function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <main>
        <HeroSection />
        <AboutSection />
        <StepsSection />
        <FeaturesSection />
        <CTASection />
        <TestimonialsSection />
      </main>
      <Footer />
    </div>
  );
}

export default App;
